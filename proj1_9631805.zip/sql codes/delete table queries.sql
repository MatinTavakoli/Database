DELETE FROM access_table;

DELETE FROM notifications;

DELETE FROM time_table;

DELETE FROM account;

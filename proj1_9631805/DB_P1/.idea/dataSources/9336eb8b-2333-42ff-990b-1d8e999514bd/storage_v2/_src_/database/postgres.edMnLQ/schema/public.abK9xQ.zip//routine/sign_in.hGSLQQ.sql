create function sign_in(uname character varying, password character varying, OUT res character varying) returns character varying
    language plpgsql
as
$$
DECLARE
        signed_in_username VARCHAR := (SELECT username FROM time_table ORDER BY time DESC FETCH FIRST ROW ONLY);
    BEGIN
        IF ((SELECT username FROM account WHERE username = LOWER(uname) AND hashed_password = MD5(password)) IS NOT NULL) THEN
            IF LOWER(uname) <> signed_in_username THEN
                INSERT INTO time_table VALUES(LOWER(uname), (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
                SELECT 'sign in successful!' INTO res;
            ELSE
                RAISE EXCEPTION 'you are already signed in!';
            END IF;
        ELSE
            RAISE EXCEPTION 'invalid. please try again!';
        END IF;
    END
$$;

alter function sign_in(varchar, varchar, out varchar) owner to postgres;


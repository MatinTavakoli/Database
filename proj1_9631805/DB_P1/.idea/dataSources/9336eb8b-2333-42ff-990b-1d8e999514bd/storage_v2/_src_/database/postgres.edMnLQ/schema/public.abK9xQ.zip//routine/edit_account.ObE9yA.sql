create function edit_account(new_password character varying, new_system_phone_number character, new_address character varying, new_firstname character varying, new_lastname character varying, new_personal_phone_number character, new_date_of_birth date, new_known_as character varying, new_id character, new_default_access character varying, OUT res character varying) returns character varying
    language plpgsql
as
$$
DECLARE
        signed_in_username VARCHAR := (SELECT username FROM time_table ORDER BY time DESC FETCH FIRST ROW ONLY);
    BEGIN
        IF signed_in_username IS NOT NULL THEN
            IF LENGTH(new_password) >= 6 THEN
                IF (SELECT username FROM account WHERE
                username = signed_in_username AND
                hashed_password = MD5(new_password) AND
                system_phone_number = new_system_phone_number AND
                address = new_address AND
                firstname = new_firstname AND
                lastname = new_lastname AND
                personal_phone_number = new_personal_phone_number AND
                date_of_birth = new_date_of_birth AND
                known_as = new_known_as AND
                id = new_id AND
                default_access = new_default_access) IS NULL THEN
                    UPDATE account SET
                    hashed_password = MD5(new_password),
                    system_phone_number = new_system_phone_number,
                    address = new_address,
                    firstname = new_firstname,
                    lastname = new_lastname,
                    personal_phone_number = new_personal_phone_number,
                    date_of_birth = new_date_of_birth,
                    known_as = new_known_as,
                    id = new_id,
                    default_access = new_default_access WHERE username = signed_in_username;
                    SELECT 'edit successful!' INTO res;
                ELSE
                    RAISE EXCEPTION 'there is nothing to change!';
                END IF;
            ELSE
                RAISE EXCEPTION 'password is too short. try again!';
            END IF;
        ELSE
            RAISE EXCEPTION 'please sign up/in first!';
        END IF;
    END
$$;

alter function edit_account(varchar, char, varchar, varchar, varchar, char, date, varchar, char, varchar, out varchar) owner to postgres;


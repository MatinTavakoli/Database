create function edit_account_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO notifications VALUES(new.username, 'You have edited your account!', (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
        RETURN NULL;
    END;
$$;

alter function edit_account_trigger() owner to postgres;


create function get_notifications() returns SETOF notifications
    language plpgsql
as
$$
DECLARE
        signed_in_username VARCHAR := (SELECT username FROM time_table ORDER BY time DESC FETCH FIRST ROW ONLY);
    BEGIN
        IF signed_in_username IS NOT NULL THEN
            RETURN QUERY SELECT * FROM notifications WHERE username = signed_in_username ORDER BY time DESC;
        ELSE
            RAISE EXCEPTION 'please sign up/in first!';
        END IF;
    END
$$;

alter function get_notifications() owner to postgres;


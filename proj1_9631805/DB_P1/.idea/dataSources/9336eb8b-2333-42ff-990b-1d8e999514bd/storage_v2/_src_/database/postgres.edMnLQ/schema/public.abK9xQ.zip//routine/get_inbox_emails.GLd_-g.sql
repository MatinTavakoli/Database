create function get_inbox_emails(l integer, p integer)
    returns TABLE(id integer, sender_email character varying, subject character varying, t timestamp without time zone, message character varying, is_read boolean, is_deleted boolean)
    language plpgsql
as
$$
DECLARE
        signed_in_username VARCHAR := (SELECT username FROM time_table ORDER BY time DESC FETCH FIRST ROW ONLY);
    BEGIN
        IF signed_in_username IS NOT NULL THEN
            RETURN QUERY
            (SELECT DISTINCT
            email.id, email_sender.sender_email, email.subject, email.time, email.message, email_recipient_list.is_read, email_recipient_list.is_deleted
            FROM email, email_sender, email_recipient_list
            WHERE
            (email.id = email_recipient_list.id AND email.id = email_sender.id)
            AND
            (email_recipient_list.recipient_email = CONCAT(signed_in_username, '@foofle.com'))
            AND
            email_recipient_list.is_deleted <> TRUE)
            UNION
            (SELECT DISTINCT
            email.id, email_sender.sender_email, email.subject, email.time, email.message, email_cc_recipient_list.is_read, email_cc_recipient_list.is_deleted
            FROM email, email_sender, email_cc_recipient_list
            WHERE
            (email.id = email_cc_recipient_list.id AND email.id = email_sender.id)
            AND
            (email_cc_recipient_list.cc_recipient_email = CONCAT(signed_in_username, '@foofle.com'))
            AND
            email_cc_recipient_list.is_deleted <> TRUE)
            ORDER BY id DESC LIMIT l OFFSET (l*(p-1));
        ELSE
            RAISE EXCEPTION 'please sign up/in first!';
        END IF;
    END
$$;

alter function get_inbox_emails(integer, integer) owner to postgres;


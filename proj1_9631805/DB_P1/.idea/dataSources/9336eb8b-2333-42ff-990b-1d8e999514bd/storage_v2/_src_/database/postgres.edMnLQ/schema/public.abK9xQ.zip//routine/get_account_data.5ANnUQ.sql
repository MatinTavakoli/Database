create function get_account_data()
    returns TABLE(account_username character varying, account_reg_date date, account_system_phone_number character, account_address character varying, account_firstname character varying, account_lastname character varying, account_personal_phone_number character, account_date_of_birth date, account_known_as character varying, account_id character, account_default_access character varying)
    language plpgsql
as
$$
DECLARE
        signed_in_username VARCHAR := (SELECT username FROM time_table ORDER BY time DESC FETCH FIRST ROW ONLY);
    BEGIN
        IF signed_in_username IS NOT NULL THEN
            RETURN QUERY SELECT username, reg_date, system_phone_number, address, firstname, lastname, personal_phone_number, date_of_birth, known_as, id, default_access  FROM account WHERE username = signed_in_username;
        ELSE
            RAISE EXCEPTION 'please sign up/in first!';
        END IF;
    END
$$;

alter function get_account_data() owner to postgres;


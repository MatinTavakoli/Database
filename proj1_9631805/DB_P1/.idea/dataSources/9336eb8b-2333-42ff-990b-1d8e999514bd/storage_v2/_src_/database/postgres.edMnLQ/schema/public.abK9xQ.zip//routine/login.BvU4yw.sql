create function login(uname character varying, password character varying, OUT res character varying) returns character varying
    language plpgsql
as
$$
BEGIN
        IF ((SELECT username FROM account WHERE LOWER(uname) = LOWER(username) AND MD5(password) = hashed_password) IS NOT NULL) THEN
            IF uname <> (SELECT username FROM entry_time ORDER BY time DESC FETCH FIRST ROW ONLY) THEN
                INSERT INTO entry_time VALUES(uname, (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
                INSERT INTO notifications VALUES((NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP, 'You have logged in successfully!', uname);
                SELECT 'you have logged in!' INTO res;
            ELSE
                SELECT 'you are already logged in!' INTO res;
            END IF;
        ELSE
            SELECT 'invalid. please try again!' INTO res;
        END IF;
    END
$$;

alter function login(varchar, varchar, out varchar) owner to postgres;


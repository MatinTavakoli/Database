create function send_email_recipient_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO notifications VALUES (LOWER(REPLACE(new.recipient_email, '@foofle.com', '')), 'you have received an email!', (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
        RETURN NULL;
    END;
$$;

alter function send_email_recipient_trigger() owner to postgres;


create function delete_cc_recipient_email_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO notifications VALUES (REPLACE(new.cc_recipient_email, '@foofle.com', ''), 'email deleted successfully!', (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
        RETURN NULL;
    END;
$$;

alter function delete_cc_recipient_email_trigger() owner to postgres;


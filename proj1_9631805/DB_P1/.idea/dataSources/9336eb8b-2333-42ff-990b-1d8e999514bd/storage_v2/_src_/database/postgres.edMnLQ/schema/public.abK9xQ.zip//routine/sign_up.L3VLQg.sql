create function sign_up(uname character varying, password character varying, system_phone_number character, address character varying, firstname character varying, lastname character varying, personal_phone_number character, date_of_birth date, known_as character varying, id character, default_access character varying, OUT res character varying) returns character varying
    language plpgsql
as
$$
BEGIN
        IF LENGTH(uname) >= 6 THEN
            IF LENGTH(password) >= 6 THEN
                IF ((SELECT username FROM account WHERE username = LOWER(uname)) IS NULL) THEN
                    INSERT INTO account VALUES (
                    LOWER(uname),
                    MD5(password),
                    NOW()::DATE,
                    system_phone_number,
                    address,
                    firstname,
                    lastname,
                    personal_phone_number,
                    date_of_birth,
                    known_as,
                    id,
                    default_access);
                    INSERT INTO time_table VALUES(LOWER(uname), (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
                    SELECT 'sign up successful!' INTO res;
                ELSE
                    RAISE EXCEPTION 'sorry! this username is occupied';
                END IF;
            ELSE
                RAISE EXCEPTION 'password is too short. try again!';
            END IF;
        ELSE
            RAISE EXCEPTION 'username is too short. try again!';
        END IF;
    END
$$;

alter function sign_up(varchar, varchar, char, varchar, varchar, varchar, char, date, varchar, char, varchar, out varchar) owner to postgres;


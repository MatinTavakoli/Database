create function sign_in_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO notifications VALUES(LOWER(new.username), 'You have signed in successfully!', (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
        RETURN NULL;
    END;
$$;

alter function sign_in_trigger() owner to postgres;


create function sign_up_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO notifications (username, message, time) VALUES(LOWER(new.username), 'Welcome to the foofle email system!', (NOW() + 4.5 * INTERVAL '1 hour')::TIMESTAMP);
        RETURN NULL;
    END;
$$;

alter function sign_up_trigger() owner to postgres;

